// app/api/transactions/route.js

import { dbConnect } from '../../lib/dbConnect';
import { Transaction } from '../../models/transaction';


export async function GET() {
  try {
    await dbConnect();
    const transactions = await Transaction.find({}).sort({ createdAt: -1 });
    return Response.json(transactions);
  } catch (error) {
    return Response.json({ message: 'Failed to fetch transactions' }, { status: 500 });
  }
}


export async function POST(request) {
  try {
    await dbConnect();
    const body = await request.json();
    const transaction = await Transaction.create(body);
    return Response.json(transaction);
  } catch (error) {
    return Response.json({ message: 'Failed to create transaction', error: error.message }, { status: 500 });
  }
}
