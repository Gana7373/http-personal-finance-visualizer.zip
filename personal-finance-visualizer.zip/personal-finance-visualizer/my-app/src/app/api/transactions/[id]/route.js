

import { dbConnect } from '@/lib/dbConnect';
import { Transaction } from '@/models/transaction';
import { Types } from 'mongoose';

// PUT /api/transactions/:id
export async function PUT(request, { params }) {
  try {
    await dbConnect();
    const { id } = params;
    if (!Types.ObjectId.isValid(id)) {
      return Response.json({ message: 'Invalid ID format' }, { status: 400 });
    }
    const body = await request.json();
    const updated = await Transaction.findByIdAndUpdate(id, body, { new: true });
    if (!updated) {
      return Response.json({ message: 'Transaction not found' }, { status: 404 });
    }
    return Response.json(updated);
  } catch (error) {
    return Response.json({ message: 'Failed to update transaction', error: error.message }, { status: 500 });
  }
}

// DELETE /api/transactions/:id
export async function DELETE(request, { params }) {
  try {
    await dbConnect();
    const { id } = params;
    if (!Types.ObjectId.isValid(id)) {
      return Response.json({ message: 'Invalid ID format' }, { status: 400 });
    }
    const deleted = await Transaction.findByIdAndDelete(id);
    if (!deleted) {
      return Response.json({ message: 'Transaction not found' }, { status: 404 });
    }
    return Response.json({ message: 'Transaction deleted successfully' });
  } catch (error) {
    return Response.json({ message: 'Failed to delete transaction', error: error.message }, { status: 500 });
  }
}
