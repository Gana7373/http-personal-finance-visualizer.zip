// utils/api.js

export async function createTransaction(data) {
    const res = await fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  
    if (!res.ok) {
      throw new Error('Failed to create transaction');
    }
  }
  
  export async function updateTransaction(id, data) {
    const res = await fetch(`/api/transactions/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  
    if (!res.ok) {
      throw new Error('Failed to update transaction');
    }
  }
  
  export async function fetchTransaction(id) {
    const res = await fetch(`/api/transactions/${id}`);
    if (!res.ok) {
      throw new Error('Failed to fetch transaction');
    }
    return res.json();
  }
  