

'use client';

import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useState, useEffect } from 'react';


const transactionSchema = z.object({
  amount: z.coerce.number({ invalid_type_error: "Amount must be a number" }),
  date: z.string({ required_error: "Date is required" }),
  description: z.string().min(1, "Description is required"),
});

export default function TransactionForm({ onSubmit, defaultValues }) {
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors }, reset } = useForm({
    resolver: zodResolver(transactionSchema),
    defaultValues: {
      amount: '',
      date: '',
      description: '',
      ...defaultValues,
    }
  });

  useEffect(() => {
    if (defaultValues) {
      reset(defaultValues);
    }
  }, [defaultValues, reset]);

  const submitHandler = async (data) => {
    try {
      setLoading(true);
      await onSubmit(data);
      reset();
    } catch (error) {
      console.error('Submit Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(submitHandler)} className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <div className="mb-4">
        <label className="block mb-1">Amount</label>
        <input
          type="number"
          step="0.01"
          {...register('amount')}
          className="w-full border p-2 rounded-md"
        />
        {errors.amount && <p className="text-red-500 text-sm">{errors.amount.message}</p>}
      </div>

      <div className="mb-4">
        <label className="block mb-1">Date</label>
        <input
          type="date"
          {...register('date')}
          className="w-full border p-2 rounded-md"
        />
        {errors.date && <p className="text-red-500 text-sm">{errors.date.message}</p>}
      </div>

      <div className="mb-4">
        <label className="block mb-1">Description</label>
        <input
          type="text"
          {...register('description')}
          className="w-full border p-2 rounded-md"
        />
        {errors.description && <p className="text-red-500 text-sm">{errors.description.message}</p>}
      </div>

      <button
        type="submit"
        disabled={loading}
        className="bg-blue-600 text-white px-4 py-2 rounded-md w-full hover:bg-blue-700 transition disabled:bg-gray-400"
      >
        {loading ? 'Saving...' : 'Save'}
      </button>
    </form>
  );
}
