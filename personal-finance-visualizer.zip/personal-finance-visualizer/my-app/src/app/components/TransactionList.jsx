

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function TransactionList() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/transactions');
      const data = await res.json();
      setTransactions(data);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this transaction?')) return;

    try {
      await fetch(`/api/transactions/${id}`, {
        method: 'DELETE',
      });
      
      fetchTransactions();
    } catch (error) {
      console.error('Error deleting transaction:', error);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  if (loading) {
    return <div>Loading transactions...</div>;
  }

  if (transactions.length === 0) {
    return <div className="text-center mt-10">No transactions found.</div>;
  }

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">All Transactions</h1>

      <table className="w-full border-collapse border">
        <thead>
          <tr className="bg-gray-100">
            <th className="border p-3 text-left">Amount</th>
            <th className="border p-3 text-left">Date</th>
            <th className="border p-3 text-left">Description</th>
            <th className="border p-3 text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          {transactions && transactions?.length > 0 && transactions.map((tx) => (
            <tr key={tx._id} className="hover:bg-gray-50">
              <td className="border p-3">₹{tx.amount}</td>
              <td className="border p-3">{new Date(tx.date).toLocaleDateString()}</td>
              <td className="border p-3">{tx.description}</td>
              <td className="border p-3">
                <button
                  onClick={() => router.push(`/transactions/edit/${tx._id}`)}
                  className="mr-2 px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(tx._id)}
                  className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
