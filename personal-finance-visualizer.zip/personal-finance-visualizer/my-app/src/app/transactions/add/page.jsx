'use client';

import TransactionForm from '../../components/TransactionForm';
import { createTransaction } from '../../utils/api';
import { useRouter } from 'next/navigation';

export default function AddTransactionPage() {
  const router = useRouter();

  const handleSubmit = async (data) => {
    await createTransaction(data);
    router.push('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-8">
      <div className="w-full max-w-lg bg-white p-8 rounded-lg shadow-lg border border-gray-200">
        <h1 className="text-3xl font-extrabold text-center text-blue-600 mb-6">
          Add New Transaction
        </h1>
        <p className="text-center text-gray-500 mb-6">
          Fill in the form below to add a new transaction to your list.
        </p>
        
        <TransactionForm onSubmit={handleSubmit} />

        <div className="mt-6 text-center">
          <button
            onClick={() => router.push('/')}
            className="text-sm text-blue-600 hover:text-blue-800 focus:outline-none"
          >
            Go back to Transaction List
          </button>
        </div>
      </div>
    </div>
  );
}
