// app/transactions/edit/[id]/page.jsx

'use client';

import TransactionForm from '@/components/TransactionForm';
import { fetchTransaction, updateTransaction } from '@/utils/api';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function EditTransactionPage({ params }) {
  const router = useRouter();
  const { id } = params;
  const [transaction, setTransaction] = useState(null);

  useEffect(() => {
    const getTransaction = async () => {
      try {
        const data = await fetchTransaction(id);
        setTransaction({
          amount: data.amount,
          date: new Date(data.date).toISOString().split('T')[0], // format date properly
          description: data.description,
        });
      } catch (error) {
        console.error('Failed to fetch transaction:', error);
      }
    };

    getTransaction();
  }, [id]);

  const handleSubmit = async (data) => {
    await updateTransaction(id, data);
    router.push('/');  // Redirect to home or transactions list after success
  };

  if (!transaction) {
    return <div>Loading...</div>;
  }

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Edit Transaction</h1>
      <TransactionForm onSubmit={handleSubmit} defaultValues={transaction} />
    </div>
  );
}
