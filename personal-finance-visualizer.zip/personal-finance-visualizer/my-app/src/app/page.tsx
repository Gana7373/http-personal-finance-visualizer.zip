'use client';

import TransactionList from '../app/components/TransactionList';
import { useRouter } from 'next/navigation';

export default function Home() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow-lg border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-extrabold text-blue-600">All Transactions</h1>
          <button
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition duration-300"
            onClick={() => router.push('/transactions/add')}
          >
            + Add Transaction
          </button>
        </div>

      
        <div className="overflow-x-auto">
          <TransactionList />
        </div>
      </div>
    </div>
  );
}
